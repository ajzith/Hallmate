## Hi there 👋

Here are some ideas to get you started:

- 🔭 I’m currently working on a project named Hallmate (Exam seating management system)
- 🌱 I’m currently learning Python , Cloud Computing and Data Mining  
- 👯 I’m looking to collaborate on Open Source Projects 
- 🤔 I’m looking for help with Cloud Computing  
- 💬 Ask me about Business , Programming and Networks
- 📫 How to reach me: sajitguru@gmail.com ,  Linkedln: https://www.linkedin.com/in/ajit-guru-s-18a21731b/ 
